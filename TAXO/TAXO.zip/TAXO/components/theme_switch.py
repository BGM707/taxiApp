import flet as ft
from utils.theme_manager import toggle_theme_mode

def ThemeSwitch(page: ft.Page):
    return ft.IconButton(
        icon=ft.icons.DARK_MODE,
        tooltip="Cambiar tema",
        on_click=lambda _: toggle_theme_mode(page),
    )