"""
This module contains reusable UI components for the Taxi App.
"""