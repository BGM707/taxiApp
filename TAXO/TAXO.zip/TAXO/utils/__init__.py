"""
This module contains utility functions and classes for the Taxi App.
"""