"""
This module contains all the screen components for the Taxi App.
"""